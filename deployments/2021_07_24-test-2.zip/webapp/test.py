a = '{"menu_items":\
    [{"item_name": "Cathead Biscuits", \
        "item_description": "Honey butter, house preserves", \
        "price": 9.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true}, \
\
\    {"item_name": "Biscuits and Sausage Gravy", \
        "item_description": "", \
        "price": 9.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Challah French Toast", \
        "item_description": "berries, maple syrup, butter", \
        "price": 10.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Pretzels & Pimento", \
        "item_description": "Hot pretzel sticks, whipped pimento", \
        "price": 9.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Street Corn Queso", \
        "item_description": "Queso fresco, pico de gallo, bacon, tortilla chips", \
        "price": 10.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Crispy Brussels Sprouts", \
        "item_description": "Hot honey, queso fresco", \
        "price": 9.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Deviled Eggs", \
        "item_description": "", \
        "price": 8.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Fried Green Tomatatoes", \
        "item_description": "Smoked shrimp, tomatillo aioli, pimento", \
        "price": 12.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Shareables", \
        "in_stock": true},\
\
\    {"item_name": "Green Chili & Pork Sausage Hash", \
        "item_description": "One egg any style, spinach, mushroom, corn, tomato, caramelized onion, poblano, avocado, queso fresco", \
        "price": 15.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Skillet Potatoes", \
        "in_stock": true},\
\
\    {"item_name": "Veggie Hash", \
        "item_description": "One egg any style, spinach, mushroom, corn, tomato, caramelized onion, poblano, avocado, queso fresco", \
        "price": 14.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Skillet Potatoes", \
        "in_stock": true},\
\
\    {"item_name": "Steak & Egg Hash", \
        "item_description": "Fried egg, caramalized onion, cheddar, ranchero sauce", \
        "price": 16.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Skillet Potatoes", \
        "in_stock": true},\
\
\    {"item_name": "Hoss Deluxe Biscuit", \
        "item_description": "Choice of (cornflake chicken or chicken fried steak), chipotle gravy, bacon, fried egg, home fries", \
        "price": 14.00, \
        "required_choice_sets": [\
            {\
                "title": "Meat",\
                "choices": [\
                    {\
                        "name": "Cornflake chicken",\
                        "price": 0.0,\
                        "in_stock": true},\
                    {\
                        "name": "Chicken fried steak",\
                        "price": 0.0,\
                        "in_stock": true}\
                    }\
                ]\
            }\
        ], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
\
\    {"item_name": "Ham & Biscuit", \
        "item_description": "Fried egg, red eye gravy, home fries", \
        "price": 12.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
\
\    {"item_name": "Backyard Chicken Sandwich", \
        "item_description": "Pepper jack, avocado, poblano, bbq, home fries", \
        "price": 14.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
\
\    {"item_name": "Pimento Cheeseburger", \
        "item_description": "Red onion, red leaf, tomato, pickles, mayo, home fries ", \
        "price": 15.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
    \
    {"item_name": "BLT", \
        "item_description": "challah, bacon, arugula, fried green tomato, pimento cheese, fried egg, house mayo", \
        "price": 13.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
\
\    {"item_name": "Sunday House Club", \
        "item_description": "Turkey, ham, bacon jam, pimento cheese, red onion, mayo, leaf lettuce, tomato ", \
        "price": 13.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true}\
\
\    {"item_name": "Sunday House Club", \
        "item_description": "Turkey, ham, bacon jam, pimento cheese, red onion, mayo, leaf lettuce, tomato ", \
        "price": 13.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [\
            {\
                "title": "Additions",\
                "choices": [\
                    {\
                        "name": "Egg",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Bacon",\
                        "price": 2.00,\
                        "in_stock": true},\
                    {\
                        "name": "Avocado",\
                        "price": 2.00,\
                        "in_stock": true}\
                ]\
            }\
        ], \
        "category": "Sandwiches", \
        "in_stock": true},\
\
\    {"item_name": "Applewood Smoked Thick-Cut Bacon", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Pork Sausage Links", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Honey Glazed Ham", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Stone Ground Grits", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Home Fries", \
        "item_description": "", \
        "price": 5.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Fruit Medley", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true},\
\
\    {"item_name": "Side Salad", \
        "item_description": "", \
        "price": 6.00, \
        "required_choice_sets": [], \
        "optional_choice_sets": [], \
        "category": "Sides", \
        "in_stock": true}\
    ],\
"order_url": "moonshine-grill"}'
