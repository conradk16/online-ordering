from flask import Flask, render_template

application = Flask(__name__)

@application.route('/')
def company_homepage():
    return render_template('company-homepage.html')

@application.route('/super-cucas-micheltorena')
def super_cucas_micheltorena():
    return render_template('super-cucas-micheltorena.html')

#@application.route('/super-cucas-micheltorena/submit-order')

if __name__ == "__main__":
    application.debug = True
    application.run()
